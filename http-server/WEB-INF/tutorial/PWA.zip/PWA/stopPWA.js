load("http-server/SERVER-SCRIPTS/lib/JavaType.js");

load("http-server/SERVER-SCRIPTS/lib/system/System.js");
load("http-server/SERVER-SCRIPTS/lib/system/Command.js");
load("http-server/SERVER-SCRIPTS/lib/system/Process.js");
load("http-server/SERVER-SCRIPTS/lib/CommandWindow.js");

pwa.process.stopHttpServer();